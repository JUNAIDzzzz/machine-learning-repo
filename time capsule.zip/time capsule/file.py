import os 
import cv2
from tqdm import tqdm
from PIL import Image

input_dir = "D:\anime_dataset\data"
output_dir = "D:\new_anime_dataset"

# Create output directory if not exists
os.makedirs(output_dir, exist_ok=True)

# Filter images by extension
image_files = [f for f in os.listdir(input_dir) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]

print(f"📸 Total images found: {len(image_files)}")

count = 0
for file in tqdm(image_files, desc="Resizing images"):
    try:
        img_path = os.path.join(input_dir, file)
        img = cv2.imread(img_path)
        if img is not None:
            resized = cv2.resize(img, (128, 128))
            cv2.imwrite(os.path.join(output_dir, file), resized)
            count += 1
    except Exception as e:
        print(f"❌ Error on {file}: {e}")

print(f"✅ Total resized images saved: {count}")
