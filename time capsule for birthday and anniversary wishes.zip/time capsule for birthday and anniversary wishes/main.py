import random
import csv
import pandas as pd
from datetime import datetime
from jinja2 import Environment, FileSystemLoader

# Step 1: Create the CSV file
data = [
    ["name", "event", "date", "image_path"],
    ["Ayesha", "birthday", "2025-07-27",  "images/ayesha.jpg"],
    ["Junaid", "anniversary", "2025-08-03",  "images/ali.jpg"],
    ["noman", "anniversary", "2025-08-5",  "images/ayesha.jpg"],
    ["noman", "birthday", "2025-08-05",  "images/ali.jpg"],
    ["Arjun", "death", "2025-07-26",  "images/ayesha.jpg"],
    ["Affan", "anniversary", "2025-08-01",  "images/ali.jpg"],
    ["Shreya", "birthday", "2025-07-27",  "images/ayesha.jpg"],
    ["Zaid", "anniversary", "2025-08-27",  "images/ali.jpg"],
    ["Jazz", "birthday", "2025-07-25",  "images/ayesha.jpg"],
    ["Dino", "anniversary", "2025-08-01",  "images/ali.jpg"]
]

with open("events.csv", mode="w", newline='') as file:
    writer = csv.writer(file)
    writer.writerows(data)

print("✅ CSV file created as events.csv")

# Step 2: Read CSV
df = pd.read_csv('events.csv')


# Step 3: Get today's date (in the same format as in CSV)
today = datetime.today().strftime("%Y-%m-%d")  # FIXED: %Y not %y

birthday_df = pd.read_csv("Book1.csv")  # update path if needed
anniversary_df = pd.read_csv("Book 2.csv")

# Step 4: Loop through rows
for index, row in df.iterrows():
    if row["date"] == today:
        name = row["name"]
        event = row["event"]
        image_path = row["image_path"]

        # Pick a random message based on event
        if event == "birthday":
            message = random.choice(birthday_df['message'].dropna().tolist())
        elif event == "anniversary":
            message = random.choice(anniversary_df['message'].dropna().tolist())
        else:
            continue  # Skip events you don't handle
        
        print(f"🎉 Generating card for {name} ({event})")
        # Setup Jinja2
        env = Environment(loader=FileSystemLoader("."))
        template = env.get_template("card.html")  # Make sure this file exists!

        # Data to inject into template
        data = {
            "name": name,
            "event": event,
            "image": image_path,
            "message": message  # inject message
        }


        # Render and save HTML
        output_html = template.render(data)
        output_file = f"card_{name}.html"  # Different file for each person

        with open(output_file, "w", encoding="utf-8") as f:
            f.write(output_html)

        print(f"✅ Card saved as {output_file}")
